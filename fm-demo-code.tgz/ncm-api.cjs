// 网易云 API 子进程
const ncm = require('@neteasecloudmusicapienhanced/api');

ncm.serveNcmApi({ port: Number(process.env.PORT || 3001), host: '127.0.0.1' })
  .then(() => console.log('[ncm-api] listening on', process.env.PORT || 3001))
  .catch(e => { console.error('[ncm-api] start failed:', e); process.exit(1); });
