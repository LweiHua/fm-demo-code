/**
 * fm-demo 后端（三平台统一网关 + 用户主页）
 *
 * 踩过的坑（改之前先看）：
 *  1) 三个内嵌 API 必须只绑 127.0.0.1
 *  2) 不要隐式透传客户端 IP（会让扫码确认永远不成功）
 *  3) 扫码流程不能带会话 cookie
 *  4) 上游包自带 2 分钟全站缓存 —— 已注释掉，别加回来
 */
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3010);
const SESSION_FILE = path.join(__dirname, '.sessions.json');

const PLATFORMS = {
  netease: { base: 'http://127.0.0.1:3001', label: '网易云音乐' },
  qq: { base: 'http://127.0.0.1:3002', label: 'QQ 音乐' },
  kugou: { base: 'http://127.0.0.1:3003', label: '酷狗音乐' },
};

/** 会话落盘，重启不丢 */
let sessions = { netease: '', qq: '', kugou: '' };
try {
  if (fs.existsSync(SESSION_FILE)) {
    const s = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf-8'));
    sessions = { ...sessions, ...s };
    console.log('[session] loaded, lengths:', Object.fromEntries(Object.entries(sessions).map(([k, v]) => [k, (v || '').length])));
  }
} catch (e) { console.warn('[session] load failed', e.message); }

function saveSessions() {
  try { fs.writeFileSync(SESSION_FILE, JSON.stringify(sessions), { mode: 0o600 }); } catch {}
}

function cleanCookie(raw) {
  if (!raw) return '';
  const parts = [];
  if (Array.isArray(raw)) {
    for (const c of raw) parts.push(...String(c).split(';'));
  } else if (typeof raw === 'string') {
    parts.push(...raw.split(/;|,(?=[^;=]+=)/));
  } else if (typeof raw === 'object') {
    for (const [k, v] of Object.entries(raw)) parts.push(`${k}=${v}`);
  }
  const seen = new Map();
  for (let p of parts) {
    p = String(p).trim();
    if (!p || !p.includes('=')) continue;
    const k = p.slice(0, p.indexOf('=')).trim();
    if (!k) continue;
    // 过滤掉 Cookie 属性
    if (/^(Max-Age|Expires|Path|Domain|SameSite|Secure|HttpOnly|Version|Comment|Priority)$/i.test(k)) continue;
    seen.set(k, p);              // 同名后写覆盖先写
  }
  return [...seen.values()].join('; ');
}

async function jget(base, p, cookie = '') {
  let url = `${base}${p}`;
  if (cookie) url += `${p.includes('?') ? '&' : '?'}cookie=${encodeURIComponent(cookie)}`;
  const r = await fetch(url, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(20000) });
  const body = await r.json().catch(() => ({}));
  return { body, setCookie: r.headers.getSetCookie?.() || [] };
}

const app = express();
app.disable('x-powered-by');

// ---------------- 扫码 ----------------
app.get('/api/:platform/login/qr', async (req, res) => {
  const p = req.params.platform, cfg = PLATFORMS[p];
  if (!cfg) return res.status(404).json({ ok: false, msg: '未知平台' });
  try {
    if (p === 'kugou') {
      const { body } = await jget(cfg.base, '/login/qr/key');
      const key = body?.data?.qrcode;
      if (!key) throw new Error(body?.error || '拿不到 qrcode');
      return res.json({ ok: true, key, qrimg: body?.data?.qrcode_img || '' });
    }
    const k = await jget(cfg.base, '/login/qr/key');
    const key = k.body?.data?.unikey;
    if (!key) throw new Error(k.body?.message || '拿不到 unikey');
    const c = await jget(cfg.base, `/login/qr/create?key=${encodeURIComponent(key)}&qrimg=true`);
    console.log('[QR]', p, 'key=' + key, 'imgLen=' + (c.body?.data?.qrimg || '').length);
    return res.json({ ok: true, key, qrimg: c.body?.data?.qrimg || '' });
  } catch (e) { return res.status(502).json({ ok: false, msg: String(e?.message || e) }); }
});

app.get('/api/:platform/login/check', async (req, res) => {
  const p = req.params.platform, cfg = PLATFORMS[p], key = String(req.query.key || '');
  if (!cfg || !key) return res.json({ code: 801 });
  try {
    const { body, setCookie } = await jget(cfg.base, `/login/qr/check?key=${encodeURIComponent(key)}`);
    if (p === 'kugou') {
      const st = body?.data?.status ?? body?.status;
      const code = st === 4 ? 803 : st === 2 ? 802 : st === 0 ? 800 : 801;
      if (code === 803) {
        // 优先用响应头 Set-Cookie（里面有 token + userid，缺一不可）
        let ck = cleanCookie(setCookie);
        if (!ck) ck = cleanCookie(body?.cookie);
        if (!ck && body?.data?.token) {
          ck = `token=${body.data.token}` + (body.data.userid ? `; userid=${body.data.userid}` : '');
        }
        sessions[p] = ck;
        saveSessions();
        console.log('[LOGIN] kugou cookieLen=' + ck.length,
                    'keys=' + ck.split(';').map(x => x.split('=')[0].trim()).join(','));
      }
      return res.json({ code });
    }
    const code = Number(body?.code);
    if (code === 803) { sessions[p] = cleanCookie(body?.cookie || setCookie); saveSessions(); }
    console.log('[CHECK]', p, 'code=' + body?.code);
    return res.json({ code: Number.isFinite(code) ? code : 801, message: body?.message ?? '' });
  } catch { return res.json({ code: 801 }); }
});

// ---------------- 用户主页 ----------------
app.get('/api/:platform/home', async (req, res) => {
  const p = req.params.platform, cfg = PLATFORMS[p];
  if (!cfg) return res.status(404).json({ ok: false, msg: '未知平台' });
  if (!sessions[p]) return res.json({ ok: false, msg: '未登录' });

  const out = { ok: true, platform: p, label: cfg.label, profile: {}, stats: {}, playlists: [], vip: null, raw: {} };
  try {
    if (p === 'netease') {
      const st = await jget(cfg.base, '/login/status', sessions[p]);
      const pr = st.body?.data?.profile || {};
      out.raw.status = st.body;
      out.profile = {
        nickname: pr.nickname || '', avatar: pr.avatarUrl || '',
        userId: pr.userId || '', vipType: pr.vipType ?? 0, level: pr.level ?? null,
        signature: pr.signature || '',
      };
      out.vip = { type: pr.vipType ?? 0 };
      out.stats = { follows: pr.follows ?? 0, fans: pr.followeds ?? 0, playlists: 0 };
      if (pr.userId) {
        const pl = await jget(cfg.base, `/user/playlist?uid=${pr.userId}&limit=50&offset=0`, sessions[p]);
        out.raw.playlist = pl.body;
        const list = pl.body?.playlist || [];
        out.playlists = list.map(x => ({
          id: x.id, name: x.name, cover: x.coverImgUrl || '', count: x.trackCount ?? 0,
          plays: x.playCount ?? 0, subscribed: !!x.subscribed, creator: x.creator?.nickname || '',
        }));
        out.stats.playlists = out.playlists.filter(x => !x.subscribed).length;
        out.stats.subscribed = out.playlists.filter(x => x.subscribed).length;
      }
    } else if (p === 'kugou') {
      const ud = await jget(cfg.base, '/user/detail', sessions[p]);
      const d = ud.body?.data || {};
      out.raw.detail = ud.body;
      out.profile = {
        nickname: d.nickname || d.username || d.nick_name || '',
        avatar: d.pic || d.avatar || d.headimg || '',
        userId: d.userid || d.user_id || '',
        vipType: (d.vip_type ?? 0),
      };
      try {
        const v = await jget(cfg.base, '/user/vip/detail', sessions[p]);
        out.raw.vip = v.body;
        const vd = v.body?.data || {};
        out.vip = { type: vd.vip_type ?? vd.is_vip ?? 0, raw: vd };
      } catch {}
      const pl = await jget(cfg.base, '/user/playlist?page=1&pagesize=50', sessions[p]);
      out.raw.playlist = pl.body;
      const list = pl.body?.data?.info || pl.body?.data?.list || pl.body?.info || [];
      out.playlists = list.map(x => ({
        id: x.listid || x.specialid || x.list_id, name: x.listname || x.specialname || x.name,
        cover: x.pic || x.imgurl || x.cover || '', count: x.songcount ?? x.count ?? 0,
        plays: x.playcount ?? 0, subscribed: !!x.subscribed || false, creator: x.nickname || '',
      }));
      out.stats = { playlists: out.playlists.length, follows: d.follows ?? 0, fans: d.fans ?? 0 };
    } else {
      // QQ：结构不稳定，先尽量挖
      const st = await jget(cfg.base, '/login/status', sessions[p]);
      out.raw.status = st.body;
      const d = st.body?.data || {};
      const pr = d.profile || d;
      out.profile = { nickname: pr.nickname || pr.nick || '', avatar: pr.avatarUrl || pr.avatar || '', userId: pr.uin || pr.userId || '', vipType: pr.vipType ?? 0 };
    }
    return res.json(out);
  } catch (e) {
    return res.status(500).json({ ok: false, msg: String(e?.message || e) });
  }
});

app.post('/api/:platform/logout', (req, res) => {
  const p = req.params.platform;
  if (PLATFORMS[p]) { sessions[p] = ''; saveSessions(); }
  res.json({ ok: true });
});

app.get('/api/platforms', (req, res) =>
  res.json(Object.entries(PLATFORMS).map(([id, v]) => ({ id, label: v.label }))));

// 调试：吐上游原始响应
app.get('/api/:platform/raw', async (req, res) => {
  const p = req.params.platform, cfg = PLATFORMS[p], ep = String(req.query.ep || '');
  if (!cfg || !ep.startsWith('/')) return res.status(400).json({ ok: false, msg: 'bad ep' });
  try {
    const { body } = await jget(cfg.base, ep, sessions[p]);
    return res.json({ ok: true, cookieLen: (sessions[p] || '').length, body });
  } catch (e) { return res.json({ ok: false, msg: String(e?.message || e) }); }
});

app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0, etag: false, extensions: ['html'] }));

app.listen(PORT, '127.0.0.1', () => console.log(`[web] http://127.0.0.1:${PORT}`));
