// QQ 音乐 API 子进程（导入即监听）
process.env.PORT = process.env.QQ_PORT || '3002';
process.env.HOST = '127.0.0.1';
require('@yakult-green-tea/qq-music-api');
console.log('[qq-api] listening on', process.env.PORT);
