// 酷狗 API 子进程
process.env.PORT = process.env.KG_PORT || '3003';
process.env.HOST = '127.0.0.1';
require('kugoumusicapi').startService()
  .then(() => console.log('[kg-api] listening on', process.env.PORT))
  .catch(e => { console.error('[kg-api] start failed:', e); process.exit(1); });
