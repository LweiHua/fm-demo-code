// 酷狗 API 子进程
// 注意：必须在 require 之前设置。
// server.js:263 里 ensureCookie('KUGOU_API_PLATFORM', process.env.platform)
// 不设就会往设备 cookie 里写字符串 "undefined"，导致所有签名失效（error_code 20018）
process.env.platform = 'standard';        // 概念版，与 folia 保持一致
process.env.PORT = process.env.KG_PORT || '3003';
process.env.HOST = '127.0.0.1';

require('kugoumusicapi').startService()
  .then(() => console.log('[kg-api] listening on', process.env.PORT, 'platform=', process.env.platform))
  .catch(e => { console.error('[kg-api] start failed:', e); process.exit(1); });
